<#
.SYNOPSIS
  Turns Windows Prefetch ON, checks that it works, and (optionally) installs an
  hourly task that keeps a permanent record of Prefetch activity.

.MODES (run in an Administrator PowerShell)
  .\enable-prefetch.ps1 -Enable         Turn on SysMain service + Prefetcher registry setting
  .\enable-prefetch.ps1 -Status         Show current state and recent .pf files
  .\enable-prefetch.ps1 -InstallBackup  Hourly task (runs as SYSTEM) that:
                                          - copies .pf files to C:\ProgramData\PrefetchBackup\files
                                          - logs every program run / deleted .pf to prefetch-log.csv
                                          - re-enables Prefetch if someone turns it off, and notes it in health.log
  .\enable-prefetch.ps1 -RemoveBackup   Remove the hourly task (backup files are kept)

.NOTES
  Prefetch only records which programs ran and when; it does not record
  browsing, incognito use or file contents.
#>

param(
    [switch]$Enable,
    [switch]$Status,
    [switch]$InstallBackup,
    [switch]$RemoveBackup
)

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Error "Run this script in an elevated (Administrator) PowerShell."; exit 1 }

if (-not ($Enable -or $Status -or $InstallBackup -or $RemoveBackup)) { $Enable = $true; $Status = $true }

$regKey   = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters'
$prefetch = Join-Path $env:SystemRoot 'Prefetch'
$root     = Join-Path $env:ProgramData 'PrefetchBackup'
$taskName = 'PrefetchBackup'

# ---------------------------------------------------------------- ENABLE
if ($Enable) {
    Write-Host "Enabling Prefetch..." -ForegroundColor Cyan
    try {
        Set-Service SysMain -StartupType Automatic -ErrorAction Stop
        Start-Service SysMain -ErrorAction SilentlyContinue
    } catch { Write-Host "  Could not configure SysMain: $($_.Exception.Message)" -ForegroundColor Red }

    try {
        Set-ItemProperty $regKey -Name EnablePrefetcher -Value 3 -ErrorAction Stop
        Set-ItemProperty $regKey -Name EnableSuperfetch -Value 3 -ErrorAction Stop
        Write-Host "  Registry: EnablePrefetcher = 3, EnableSuperfetch = 3" -ForegroundColor Green
    } catch { Write-Host "  Could not write registry: $($_.Exception.Message)" -ForegroundColor Red }

    Write-Host "  Restart the laptop, use a few programs, then run -Status to confirm .pf files appear." -ForegroundColor Yellow
}

# ---------------------------------------------------------------- STATUS
if ($Status) {
    Write-Host ""
    Write-Host "=== Prefetch status ===" -ForegroundColor White
    $svc = Get-Service SysMain -ErrorAction SilentlyContinue
    $pp  = Get-ItemProperty $regKey -ErrorAction SilentlyContinue
    $ok1 = $svc -and $svc.Status -eq 'Running'
    $ok2 = $pp.EnablePrefetcher -eq 3
    Write-Host ("SysMain service  : {0} / {1}" -f $svc.Status, $svc.StartType) -ForegroundColor $(if ($ok1) { 'Green' } else { 'Red' })
    Write-Host ("EnablePrefetcher : {0}  (3 = on)" -f $pp.EnablePrefetcher) -ForegroundColor $(if ($ok2) { 'Green' } else { 'Red' })

    $pf = @(Get-ChildItem $prefetch -Filter *.pf -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    Write-Host ("Prefetch files   : {0}" -f $pf.Count)
    if ($pf.Count) {
        Write-Host "Most recent:"
        $pf | Select-Object -First 8 | ForEach-Object { Write-Host ("   {0}   {1}" -f $_.LastWriteTime, $_.Name) }
    } elseif ($ok1 -and $ok2) {
        Write-Host "No files yet. Restart, open a few programs, wait 1-2 minutes and check again." -ForegroundColor Yellow
    }

    $t = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    Write-Host ("Hourly backup    : {0}" -f $(if ($t) { "installed ($($t.State))" } else { 'not installed (use -InstallBackup)' }))
    $health = Join-Path $root 'health.log'
    if (Test-Path $health) {
        Write-Host ""
        Write-Host "Tamper / repair history (health.log, last 10 lines):" -ForegroundColor Yellow
        Get-Content $health -Tail 10 | ForEach-Object { Write-Host "   $_" }
    }
    $log = Join-Path $root 'prefetch-log.csv'
    if (Test-Path $log) {
        $rows = @(Import-Csv $log)
        $del  = @($rows | Where-Object { $_.LastRun -eq 'DELETED' })
        Write-Host ""
        Write-Host ("Activity log     : {0} entries, {1} deletion(s) of .pf files noticed  ({2})" -f $rows.Count, $del.Count, $log)
    }
}

# ---------------------------------------------------------------- REMOVE
if ($RemoveBackup) {
    schtasks /Delete /TN $taskName /F 2>$null | Out-Null
    Write-Host "Hourly task removed. Backup files remain in $root" -ForegroundColor Green
}

# ---------------------------------------------------------------- INSTALL BACKUP
if ($InstallBackup) {
    New-Item -ItemType Directory -Path $root -Force | Out-Null
    $helper = Join-Path $root 'backup-prefetch.ps1'

    $helperCode = @'
$src    = 'C:\Windows\Prefetch'
$root   = 'C:\ProgramData\PrefetchBackup'
$files  = Join-Path $root 'files'
$log    = Join-Path $root 'prefetch-log.csv'
$state  = Join-Path $root 'state.json'
$health = Join-Path $root 'health.log'
New-Item -ItemType Directory -Path $files -Force | Out-Null

# 1) health check + automatic repair
$k = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters'
$issues = @()
$ep = (Get-ItemProperty $k -ErrorAction SilentlyContinue).EnablePrefetcher
if ($ep -ne 3) { $issues += "EnablePrefetcher was '$ep' (reset to 3)"; Set-ItemProperty $k -Name EnablePrefetcher -Value 3 -ErrorAction SilentlyContinue }
$svc = Get-Service SysMain -ErrorAction SilentlyContinue
if ($svc) {
    if ($svc.StartType -ne 'Automatic') { $issues += "SysMain start type was '$($svc.StartType)' (reset to Automatic)"; Set-Service SysMain -StartupType Automatic }
    if ($svc.Status -ne 'Running')      { $issues += "SysMain service was $($svc.Status) (started)"; Start-Service SysMain -ErrorAction SilentlyContinue }
}
if ($issues) { Add-Content $health ("{0}  TAMPERING/FIXED: {1}" -f (Get-Date -Format s), ($issues -join '; ')) }

# 2) copy new/updated .pf files
robocopy $src $files *.pf /XO /R:0 /W:0 /NFL /NDL /NJH /NJS /NP | Out-Null

# 3) log every new or re-run program, and every deleted .pf
$prev = @{}
if (Test-Path $state) {
    try { (Get-Content $state -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $prev[$_.Name] = $_.Value } } catch { }
}
$now = Get-Date -Format s
$rows = @()
$current = @{}
foreach ($f in Get-ChildItem $src -Filter *.pf -ErrorAction SilentlyContinue) {
    $stamp = $f.LastWriteTime.ToString('s')
    $current[$f.Name] = $stamp
    if ($prev[$f.Name] -ne $stamp) {
        $rows += [pscustomobject]@{ Seen = $now; Program = $f.Name; LastRun = $stamp; SizeKB = [math]::Round($f.Length / 1KB, 1) }
    }
}
foreach ($name in @($prev.Keys)) {
    if (-not $current.ContainsKey($name)) {
        $rows += [pscustomobject]@{ Seen = $now; Program = $name; LastRun = 'DELETED'; SizeKB = '' }
    }
}
if ($rows) { $rows | Export-Csv $log -Append -NoTypeInformation -Encoding UTF8 }
$current | ConvertTo-Json | Set-Content $state -Encoding UTF8
'@
    Set-Content -Path $helper -Value $helperCode -Encoding UTF8

    # only SYSTEM and Administrators may change the backup folder
    icacls $root /inheritance:r /grant "SYSTEM:(OI)(CI)F" "Administrators:(OI)(CI)F" | Out-Null

    $tr = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$helper`""
    schtasks /Create /TN $taskName /SC HOURLY /MO 1 /RU SYSTEM /RL HIGHEST /TR $tr /F | Out-Null
    schtasks /Run /TN $taskName | Out-Null

    Write-Host "Hourly backup task installed (runs as SYSTEM) and started." -ForegroundColor Green
    Write-Host "  Backup copies : $root\files"
    Write-Host "  Activity log  : $root\prefetch-log.csv"
    Write-Host "  Tamper log    : $root\health.log"
    Write-Host "Only administrators can edit that folder. Run -Status any time to review." -ForegroundColor Cyan
}
