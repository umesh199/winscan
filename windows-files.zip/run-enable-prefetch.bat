@echo off
setlocal
title Enable Prefetch

REM ---- Self-elevate to Administrator ----
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SCRIPT=%~dp0enable-prefetch.ps1"
if not exist "%SCRIPT%" (
    echo ERROR: enable-prefetch.ps1 must be in the same folder as this .bat file.
    pause
    exit /b 1
)

:menu
echo.
echo ==========================================
echo   Prefetch logging
echo ==========================================
echo   1. Enable Prefetch now (then restart the PC)
echo   2. Show status / recent Prefetch files
echo   3. Install hourly backup + auto-repair + activity log
echo   4. Remove the hourly backup task
echo   5. Exit
echo.
set /p choice=Choose an option (1-5): 

if "%choice%"=="1" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Enable
if "%choice%"=="2" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Status
if "%choice%"=="3" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -InstallBackup
if "%choice%"=="4" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -RemoveBackup
if "%choice%"=="5" exit /b

echo.
pause
goto menu
