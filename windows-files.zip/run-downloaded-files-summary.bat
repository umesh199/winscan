@echo off
setlocal
title Downloaded Files Summary (last 24 hours)

REM ---- Self-elevate so all user profiles can be read ----
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SCRIPT=%~dp0downloaded-files-summary.ps1"
if not exist "%SCRIPT%" (
    echo ERROR: downloaded-files-summary.ps1 must be in the same folder as this .bat file.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
echo.
pause
