<#
.SYNOPSIS
  Checks (1) whether the installed antivirus looks genuine and (2) whether
  anything has been clearing Windows event logs.

.WHAT IT CHECKS
  - Antivirus products registered with Windows Security Center, their state
  - Digital signature of the AV program and its services (valid? signed by
    the right company for that product name?)
  - Install location (real AVs live in Program Files, not AppData/Temp/Downloads)
  - Microsoft Defender status and any exclusions (folders hidden from scanning)
  - Event log clear events (Security 1102, System 104), log sizes / oldest entry
  - Commands such as wevtutil / Clear-EventLog, if process logging was enabled

.USAGE (Administrator PowerShell)
  .\check-antivirus-genuine.ps1
  .\check-antivirus-genuine.ps1 -Days 60
  A copy of the output is saved to Desktop\antivirus-check.txt

.NOTE
  A valid signature from the right publisher is strong evidence the program
  is the real product, but it is not a guarantee of safety. For anything
  flagged, check the SHA256 shown on virustotal.com.
#>

param(
    [int]$Days = 30,
    [string]$OutFile = "$([Environment]::GetFolderPath('Desktop'))\antivirus-check.txt"
)

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Error "Run this script in an elevated (Administrator) PowerShell."; exit 1 }

Start-Transcript -Path $OutFile -Force | Out-Null
$flags = New-Object System.Collections.Generic.List[string]

# publisher expected for each product name
$vendors = [ordered]@{
    'Windows Defender|Microsoft Defender' = 'Microsoft'
    'Avast'                  = 'Avast'
    'AVG'                    = 'AVG|Avast'
    'McAfee'                 = 'McAfee|Musarubra|Trellix'
    'Norton|Symantec|LifeLock' = 'Norton|Symantec|Gen Digital'
    'Kaspersky'              = 'Kaspersky'
    'Bitdefender'            = 'Bitdefender'
    'ESET'                   = 'ESET'
    'Trend Micro'            = 'Trend Micro'
    'Sophos'                 = 'Sophos'
    'Malwarebytes'           = 'Malwarebytes'
    'Quick Heal|Seqrite'     = 'Quick Heal|Seqrite'
    'K7'                     = 'K7'
    'Avira'                  = 'Avira'
    'F-Secure|WithSecure'    = 'F-Secure|WithSecure'
    'Webroot'                = 'Webroot|Carbonite|OpenText'
    'Panda|WatchGuard'       = 'Panda|WatchGuard'
    'Comodo|Xcitium'         = 'Comodo|Xcitium'
    'Dr\.?\s?Web'            = 'Doctor Web'
    '360'                    = 'Qihoo|360'
}

function Get-Sig([string]$p) {
    $o = [pscustomobject]@{ Exists = $false; Status = ''; Subject = ''; Signer = '' }
    if (-not $p -or -not (Test-Path -LiteralPath $p)) { return $o }
    $o.Exists = $true
    $s = Get-AuthenticodeSignature -LiteralPath $p
    $o.Status = $s.Status.ToString()
    if ($s.SignerCertificate) {
        $o.Subject = $s.SignerCertificate.Subject
        $o.Signer  = $o.Subject -replace '^.*?CN=([^,]+).*$', '$1'
    }
    return $o
}

function Write-Ok($t)   { Write-Host "  [ OK ] $t" -ForegroundColor Green }
function Write-Bad($t)  { Write-Host "  [FLAG] $t" -ForegroundColor Red;    $script:flags.Add($t) }
function Write-Warn($t) { Write-Host "  [WARN] $t" -ForegroundColor Yellow; $script:flags.Add($t) }

# =================== 1) Registered antivirus products ===================
Write-Host ""
Write-Host "=== 1. Antivirus products registered in Windows Security Center ===" -ForegroundColor White
$products = @(Get-CimInstance -Namespace root\SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction SilentlyContinue)
if (-not $products) { Write-Warn "No antivirus is registered with Windows Security Center (or this is a Server edition)." }

$onCount = 0
foreach ($p in $products) {
    $ps    = [int]$p.productState
    $state = if ($ps -band 0x1000) { 'ON' } elseif ($ps -band 0x2000) { 'SNOOZED' } else { 'OFF' }
    $defs  = if ($ps -band 0x10) { 'OUT OF DATE' } else { 'up to date' }
    if ($state -eq 'ON') { $onCount++ }

    Write-Host ""
    Write-Host ("{0}" -f $p.displayName) -ForegroundColor Cyan
    Write-Host ("  State: {0}   Virus definitions: {1}" -f $state, $defs)

    $exe = $p.pathToSignedProductExe
    if ($exe -match 'windowsdefender|^\s*$') {
        $exe = $null
        $mp = Get-Process MsMpEng -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($mp -and $mp.Path) { $exe = $mp.Path }
        if (-not $exe) {
            $plat = Get-ChildItem "$env:ProgramData\Microsoft\Windows Defender\Platform" -Directory -ErrorAction SilentlyContinue |
                    Sort-Object Name -Descending | Select-Object -First 1
            if ($plat) { $exe = Join-Path $plat.FullName 'MsMpEng.exe' }
        }
    }
    Write-Host ("  Program: {0}" -f $exe)

    if ($state -ne 'ON')           { Write-Warn "$($p.displayName): protection is $state." }
    if ($defs -ne 'up to date')    { Write-Warn "$($p.displayName): virus definitions are out of date." }

    # signature
    $sig = Get-Sig $exe
    if (-not $sig.Exists) {
        Write-Bad "$($p.displayName): registered program file not found on disk ($exe) - registration may be fake or leftover."
    } else {
        if ($sig.Status -eq 'Valid') { Write-Ok "Digital signature valid. Signed by: $($sig.Signer)" }
        else                         { Write-Bad "$($p.displayName): program is NOT validly signed (status: $($sig.Status))." }

        $expected = $null
        foreach ($k in $vendors.Keys) { if ($p.displayName -match $k) { $expected = $vendors[$k]; break } }
        if ($expected) {
            if ($sig.Subject -match $expected) { Write-Ok "Publisher matches the product name." }
            else { Write-Bad "$($p.displayName): signed by '$($sig.Signer)', which does not match the expected publisher ($expected)." }
        } else {
            Write-Warn "$($p.displayName): unknown/uncommon antivirus - cannot verify publisher automatically. Signed by '$($sig.Signer)'."
        }

        # location
        if ($exe -match '\\Users\\|\\AppData\\|\\Temp\\|\\Downloads\\|\\Desktop\\') {
            Write-Bad "$($p.displayName): runs from a user folder ($exe). Real antivirus programs install under Program Files."
        } elseif ($exe -match '\\Program Files( \(x86\))?\\|\\ProgramData\\Microsoft\\Windows Defender\\|\\Windows\\') {
            Write-Ok "Installed in a normal system location."
        } else {
            Write-Warn "$($p.displayName): unusual install location ($exe)."
        }

        $fi = Get-Item -LiteralPath $exe
        Write-Host ("  File created: {0}   Version: {1}" -f $fi.CreationTime, $fi.VersionInfo.FileVersion)
        try { Write-Host ("  SHA256: {0}" -f (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash) } catch { }

        # services of the same product
        $root = if ($exe -match '^(.*?\\Program Files( \(x86\))?\\[^\\]+)') { $Matches[1] } else { Split-Path $exe -Parent }
        $svcs = Get-CimInstance Win32_Service | Where-Object { $_.PathName -like "*$root*" }
        $bad = 0
        foreach ($s in $svcs) {
            $sp = if ($s.PathName -match '^"?([^"]+?\.exe)') { $Matches[1] } else { $null }
            $ss = Get-Sig $sp
            if ($ss.Exists -and $ss.Status -ne 'Valid') { $bad++; Write-Bad "Service '$($s.DisplayName)' binary is not validly signed ($($ss.Status)): $sp" }
        }
        if ($svcs) { if (-not $bad) { Write-Ok "$(@($svcs).Count) related service(s), all validly signed." } }
        else       { Write-Warn "$($p.displayName): no Windows service found for this product; real antivirus normally runs as a service." }
    }
}
if ($onCount -gt 1) { Write-Warn "More than one antivirus reports ON. Genuine products normally switch each other off; this can mean a fake or conflicting program." }

# =================== 2) Microsoft Defender ===================
Write-Host ""
Write-Host "=== 2. Microsoft Defender ===" -ForegroundColor White
try {
    $mp = Get-MpComputerStatus -ErrorAction Stop
    Write-Host ("  Service enabled : {0}   Real-time protection: {1}   Mode: {2}" -f $mp.AMServiceEnabled, $mp.RealTimeProtectionEnabled, $mp.AMRunningMode)
    Write-Host ("  Signatures      : {0}   Last updated: {1}" -f $mp.AntivirusSignatureVersion, $mp.AntivirusSignatureLastUpdated)
    if ($mp.TamperProtectionSource -or $mp.IsTamperProtected -eq $false) { Write-Host ("  Tamper protection: {0}" -f $mp.IsTamperProtected) }
    $pref = Get-MpPreference
    $ex = @($pref.ExclusionPath) + @($pref.ExclusionProcess) + @($pref.ExclusionExtension) | Where-Object { $_ }
    if ($ex) {
        $exFile = "$([Environment]::GetFolderPath('Desktop'))\defender-exclusions.txt"
        $ex | Out-File $exFile -Encoding UTF8
        Write-Warn "Defender has $(@($ex).Count) exclusion(s), i.e. places it does not scan. Full list saved to $exFile"

        $broad = @($ex | Where-Object { $_ -match '^[A-Za-z]:\\?$|\\Program Files( \(x86\))?\\?$|\\AppData\\Local\\?$|\\AppData\\?$|\\Users\\[^\\]+\\?$|\\Windows\\?$|\\Temp\\?$|\\Downloads\\?$' })
        foreach ($b in $broad) { Write-Bad "Very broad exclusion: $b  (anything placed inside is invisible to Defender)" }

        $rand = @($ex | Where-Object { $_ -match 'cversions_|\\AppData\\Local\\[^\\]+\\[^\\]*\.exe$' })
        if ($rand.Count -gt 10) {
            Write-Bad "$($rand.Count) auto-generated-looking exclusions (random folder + .exe names under AppData\Local). This pattern is typical of malware excluding its own copies."
        }

        $files = @($ex | Where-Object { $_ -match '\.exe$' -and (Test-Path -LiteralPath $_) })
        Write-Host ("  Excluded .exe files that still exist on disk: {0}" -f $files.Count)
        $unsigned = @(foreach ($f in $files) { $sg = Get-Sig $f; if ($sg.Status -ne 'Valid') { [pscustomobject]@{ Path = $f; Status = $sg.Status } } })
        if ($unsigned.Count) {
            Write-Bad "$($unsigned.Count) excluded program(s) are unsigned or have an invalid signature (first 15 shown):"
            $unsigned | Select-Object -First 15 | ForEach-Object { Write-Host "    $($_.Path)  [$($_.Status)]" -ForegroundColor Red }
        }
    } else { Write-Ok "No Defender scan exclusions." }
    $off = Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Windows Defender/Operational'; Id = 5001; StartTime = (Get-Date).AddDays(-$Days) } -ErrorAction SilentlyContinue
    if ($off) { Write-Warn "Defender real-time protection was turned off $(@($off).Count) time(s) in the last $Days days (latest: $($off[0].TimeCreated))." }
} catch { Write-Host "  Defender status not available (a third-party antivirus may have replaced it)." -ForegroundColor DarkGray }

# =================== 3) Event log clearing ===================
Write-Host ""
Write-Host "=== 3. Windows event logs cleared in the last $Days days ===" -ForegroundColor White
$since = (Get-Date).AddDays(-$Days)
$cleared = @()
$cleared += Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 1102; StartTime = $since } -ErrorAction SilentlyContinue
$cleared += Get-WinEvent -FilterHashtable @{ LogName = 'System';   Id = 104;  StartTime = $since } -ErrorAction SilentlyContinue
if ($cleared) {
    foreach ($e in ($cleared | Sort-Object TimeCreated -Descending)) {
        $raw  = $e.ToXml()
        $usr  = [regex]::Match($raw, '<SubjectUserName>([^<]*)<').Groups[1].Value
        $dom  = [regex]::Match($raw, '<SubjectDomainName>([^<]*)<').Groups[1].Value
        $log  = if ($e.Id -eq 1102) { 'Security' } else { [regex]::Match($raw, '<Channel>([^<]*)<').Groups[1].Value }
        if (-not $log) { $log = '(unknown)' }
        $who  = if ($usr) { "$dom\$usr" } else { '(user not recorded)' }
        Write-Bad "$log log cleared at $($e.TimeCreated) by $who"
    }
    Write-Host "  A genuine antivirus does not clear Windows event logs. Clearing is done by a user/admin (wevtutil, Event Viewer) or a script." -ForegroundColor Yellow
} else { Write-Ok "No 'log cleared' events found." }

Write-Host ""
Write-Host "  Log age check (a log whose oldest entry is very recent was probably reset):"
foreach ($n in 'Security', 'System', 'Application') {
    $l = Get-WinEvent -ListLog $n -ErrorAction SilentlyContinue
    $old = Get-WinEvent -LogName $n -Oldest -MaxEvents 1 -ErrorAction SilentlyContinue
    Write-Host ("   {0,-12} records: {1,-8} oldest entry: {2}   max size: {3} MB" -f $n, $l.RecordCount, $old.TimeCreated, [math]::Round($l.MaximumSizeInBytes / 1MB))
}

$cmds = Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4688; StartTime = $since } -ErrorAction SilentlyContinue
$hits = foreach ($e in $cmds) {
    $x = [xml]$e.ToXml(); $d = @{}
    foreach ($i in $x.Event.EventData.Data) { $d[$i.Name] = $i.'#text' }
    if ([string]$d['CommandLine'] -match 'wevtutil.*\bcl\b|clear-eventlog|remove-eventlog|Clear-WinEvent|del.*\.evtx|\.Clear\(\)') {
        [pscustomobject]@{ Time = $e.TimeCreated; User = $d['SubjectUserName']; Parent = $d['ParentProcessName']; Cmd = $d['CommandLine'] }
    }
}
if ($hits) {
    foreach ($h in $hits) { Write-Bad "Log-clearing command at $($h.Time) by $($h.User) (parent: $($h.Parent)): $($h.Cmd)" }
}

# =================== summary ===================
Write-Host ""
Write-Host "=== Summary ===" -ForegroundColor White
if ($flags.Count -eq 0) {
    Write-Host "No red flags found. The antivirus looks genuine and no log clearing was detected." -ForegroundColor Green
} else {
    Write-Host "$($flags.Count) point(s) need attention:" -ForegroundColor Red
    $flags | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
}
Write-Host ""
Write-Host "Output saved to: $OutFile" -ForegroundColor Cyan
Stop-Transcript | Out-Null
