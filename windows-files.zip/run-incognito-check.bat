@echo off
setlocal
title Incognito / Private Browsing Check

REM ---- Self-elevate to Administrator (needed to read the Security log) ----
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator rights...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SCRIPT=%~dp0check-incognito-24h.ps1"
if not exist "%SCRIPT%" (
    echo ERROR: check-incognito-24h.ps1 must be in the same folder as this .bat file.
    pause
    exit /b 1
)

:menu
echo.
echo ==========================================
echo   Private Browsing Check
echo ==========================================
echo   1. First-time setup (enable logging)
echo   2. Check last 24 hours
echo   3. Check last 24 hours and save CSV (C:\Logs\incognito.csv)
echo   4. Block incognito / InPrivate completely
echo   5. Exit
echo.
set /p choice=Choose an option (1-5): 

if "%choice%"=="1" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Setup
if "%choice%"=="2" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
if "%choice%"=="3" (
    if not exist "C:\Logs" mkdir "C:\Logs"
    powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -OutFile "C:\Logs\incognito.csv"
)
if "%choice%"=="4" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -BlockPrivateMode
if "%choice%"=="5" exit /b

echo.
pause
goto menu
