@echo off
setlocal
title Prefetch Clean Monitor

REM ---- Self-elevate to Administrator ----
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SCRIPT=%~dp0prefetch-clean-monitor.ps1"
if not exist "%SCRIPT%" (
    echo ERROR: prefetch-clean-monitor.ps1 must be in the same folder as this .bat file.
    pause
    exit /b 1
)

:menu
echo.
echo ==========================================
echo   What is cleaning the Prefetch folder?
echo ==========================================
echo   1. Setup: start logging deletions (do this first, once)
echo   2. Check likely suspects now (cleaner apps, tasks, services)
echo   3. Report: who deleted Prefetch files (last 24 hours)
echo   4. Stop logging (remove Prefetch auditing)
echo   5. Exit
echo.
set /p choice=Choose an option (1-5): 

if "%choice%"=="1" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Setup
if "%choice%"=="2" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Suspects
if "%choice%"=="3" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Report
if "%choice%"=="4" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -Remove
if "%choice%"=="5" exit /b

echo.
pause
goto menu
