<#
.SYNOPSIS
  Checks whether Chrome/Edge/Firefox/Brave/Opera were launched in private
  (incognito / InPrivate) mode during the last N hours (default 24).

.USAGE
  1. Open PowerShell as Administrator.
  2. First run, enable logging:   .\check-incognito-24h.ps1 -Setup
  3. Check anytime afterwards:    .\check-incognito-24h.ps1
     Different window:            .\check-incognito-24h.ps1 -Hours 48
     Export for a dashboard:      .\check-incognito-24h.ps1 -OutFile C:\Logs\incognito.csv

.NOTES
  - Only events AFTER -Setup are recorded, so run -Setup first and check later.
  - Detects launches that carry a private flag (shortcut / taskbar jump list).
    Opening a private window from inside an already-running browser
    (Ctrl+Shift+N) does not start a new process and cannot be detected here.
  - To block private mode entirely, run with -BlockPrivateMode.
#>

param(
    [int]$Hours = 24,
    [switch]$Setup,
    [switch]$BlockPrivateMode,
    [string]$OutFile
)

# Require admin (Security log needs it)
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Error "Please run this script in an elevated (Administrator) PowerShell."
    exit 1
}

if ($Setup) {
    auditpol /set /subcategory:"Process Creation" /success:enable | Out-Null
    reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" `
        /v ProcessCreationIncludeCmdLine_Enabled /t REG_DWORD /d 1 /f | Out-Null
    Write-Host "Process-creation logging with command lines is now enabled." -ForegroundColor Green
    Write-Host "Run the script again without -Setup later to see results."
    return
}

if ($BlockPrivateMode) {
    reg add "HKLM\SOFTWARE\Policies\Google\Chrome"  /v IncognitoModeAvailability /t REG_DWORD /d 1 /f | Out-Null
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Edge" /v InPrivateModeAvailability /t REG_DWORD /d 1 /f | Out-Null
    Write-Host "Chrome incognito and Edge InPrivate disabled. Restart the browsers." -ForegroundColor Green
    Write-Host "For Firefox, add { `"policies`": { `"DisablePrivateBrowsing`": true } } to distribution\policies.json."
    return
}

$since = (Get-Date).AddHours(-$Hours)

$events = Get-WinEvent -FilterHashtable @{
    LogName   = 'Security'
    Id        = 4688
    StartTime = $since
} -ErrorAction SilentlyContinue

if (-not $events) {
    Write-Host "No process-creation events found. Did you run with -Setup earlier?" -ForegroundColor Yellow
    return
}

$browserRegex = 'chrome\.exe|msedge\.exe|firefox\.exe|brave\.exe|opera\.exe'
$flags        = '--incognito', '-inprivate', '--inprivate', '-private-window', '-private '

$hits = foreach ($e in $events) {
    $xml  = [xml]$e.ToXml()
    $data = @{}
    foreach ($d in $xml.Event.EventData.Data) { $data[$d.Name] = $d.'#text' }

    $proc = $data['NewProcessName']
    $cmd  = $data['CommandLine']
    if ($proc -match $browserRegex -and $cmd) {
        foreach ($f in $flags) {
            if ($cmd -like "*$f*") {
                [pscustomobject]@{
                    Time    = $e.TimeCreated
                    Browser = [IO.Path]::GetFileName($proc)
                    User    = $data['SubjectUserName']
                    CmdLine = $cmd
                }
                break
            }
        }
    }
}

if ($hits) {
    Write-Host "Private browsing detected in the last $Hours hour(s):" -ForegroundColor Red
    $hits | Sort-Object Time | Format-Table Time, Browser, User -AutoSize
    if ($OutFile) {
        $hits | Sort-Object Time | Export-Csv -Path $OutFile -NoTypeInformation -Encoding UTF8
        Write-Host "Saved to $OutFile"
    }
} else {
    Write-Host "No private-browsing launches found in the last $Hours hour(s)." -ForegroundColor Green
    if ($OutFile) { "" | Out-File $OutFile }
}
