<#
.SYNOPSIS
  Lists user files created/modified in the last N hours (default 24) on all
  fixed drives, skipping Windows/system/program/cache folders.
  Files downloaded from the internet (Zone.Identifier mark) are flagged.

.USAGE
  .\recent-file-changes.ps1                      # last 24 hours, all drives
  .\recent-file-changes.ps1 -Hours 48
  .\recent-file-changes.ps1 -DownloadedOnly      # only internet-downloaded files
  .\recent-file-changes.ps1 -Drives C:,D:        # specific drives
  .\recent-file-changes.ps1 -OutFile D:\report.csv

  Run as Administrator to scan every user's folders.
#>

param(
    [int]$Hours = 24,
    [string[]]$Drives,
    [switch]$DownloadedOnly,
    [string]$OutFile = "$([Environment]::GetFolderPath('Desktop'))\recent-file-changes.csv"
)

$cutoff = (Get-Date).AddHours(-$Hours)

if (-not $Drives) {
    $Drives = (Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3").DeviceID   # fixed disks only
}

# Folders to skip: system, programs, caches, temp
$excludeDirs = @(
    'Windows', 'Program Files', 'Program Files (x86)', 'ProgramData',
    '$Recycle.Bin', 'System Volume Information', 'Recovery', 'PerfLogs',
    '$WinREAgent', 'Config.Msi', 'MSOCache', 'WinSxS',
    'Temp', 'INetCache', 'Cache', 'Code Cache', 'GPUCache', 'Cache2',
    'CrashDumps', 'Packages', 'WindowsApps', 'node_modules', '.git'
)
$excludeFiles = @('pagefile.sys', 'hiberfil.sys', 'swapfile.sys', 'DumpStack.log*', '*.tmp', 'NTUSER.DAT*', 'ntuser.ini', 'desktop.ini', 'thumbs.db')

$results = New-Object System.Collections.Generic.List[object]
$tmpDest = Join-Path $env:TEMP 'rc_dummy_dest'

foreach ($drive in $Drives) {
    Write-Host "Scanning $drive ..." -ForegroundColor Cyan
    $log = Join-Path $env:TEMP "rc_scan_$([guid]::NewGuid()).txt"

    # Robocopy in list-only mode is the fastest way to walk a whole drive.
    # MAXAGE:2 is a coarse prefilter (day based); exact time is filtered below.
    $args = @("$drive\", $tmpDest, '/L', '/S', '/XJ', '/R:0', '/W:0',
              '/MAXAGE:2', '/NJH', '/NJS', '/NDL', '/NC', '/NS', '/NP', '/FP',
              "/UNILOG:$log", '/XD') + $excludeDirs + @('/XF') + $excludeFiles
    & robocopy @args | Out-Null

    if (Test-Path $log) {
        foreach ($line in Get-Content -Path $log -Encoding Unicode) {
            $path = $line.Trim()
            if (-not $path -or $path -notmatch '^[A-Za-z]:\\') { continue }
            try {
                $item = Get-Item -LiteralPath $path -Force -ErrorAction Stop
            } catch { continue }

            $changed = if ($item.LastWriteTime -gt $item.CreationTime) { $item.LastWriteTime } else { $item.CreationTime }
            if ($changed -lt $cutoff) { continue }

            # Internet-downloaded files carry an NTFS "Zone.Identifier" stream
            $zone = Get-Item -LiteralPath $path -Stream Zone.Identifier -ErrorAction SilentlyContinue
            $isDownloaded = [bool]$zone
            $inDownloads  = $path -match '\\Downloads\\'

            if ($DownloadedOnly -and -not ($isDownloaded -or $inDownloads)) { continue }

            $results.Add([pscustomobject]@{
                Changed    = $changed
                Created    = $item.CreationTime
                Modified   = $item.LastWriteTime
                SizeKB     = [math]::Round($item.Length / 1KB, 1)
                Downloaded = $isDownloaded
                InDownloadsFolder = $inDownloads
                Name       = $item.Name
                Path       = $item.FullName
            })
        }
        Remove-Item $log -Force -ErrorAction SilentlyContinue
    }
}

if ($results.Count -eq 0) {
    Write-Host "No matching files changed in the last $Hours hour(s)." -ForegroundColor Green
    return
}

$sorted = $results | Sort-Object Changed -Descending
$sorted | Select-Object Changed, SizeKB, Downloaded, Path | Format-Table -AutoSize -Wrap
$sorted | Export-Csv -Path $OutFile -NoTypeInformation -Encoding UTF8

Write-Host ""
Write-Host "$($results.Count) file(s) found. Downloaded from internet: $(($results | Where-Object Downloaded).Count)" -ForegroundColor Yellow
Write-Host "Report saved to: $OutFile"
