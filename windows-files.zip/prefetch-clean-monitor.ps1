<#
.SYNOPSIS
  Finds out WHAT is deleting files from C:\Windows\Prefetch (and who started it).

.HOW IT WORKS
  -Setup    Turns on Windows file-system auditing for deletions inside the
            Prefetch folder (plus process command-line logging) and enlarges
            the Security log so entries are not overwritten quickly.
  -Report   Reads the Security log and shows, per program, how many Prefetch
            files it deleted, when, and (if available) how that program was
            launched and by which parent process.
  -Suspects Looks for likely cleaners right now: Prefetch/SysMain state,
            scheduled tasks, services, startup entries and installed
            "cleaner/optimizer" programs.
  -Remove   Turns the Prefetch deletion auditing off again.

.USAGE (Administrator PowerShell)
  .\prefetch-clean-monitor.ps1 -Setup        # once
  .\prefetch-clean-monitor.ps1 -Suspects     # immediate checks
  .\prefetch-clean-monitor.ps1 -Report       # later, after the laptop was used
  .\prefetch-clean-monitor.ps1 -Report -Hours 72
#>

param(
    [switch]$Setup,
    [switch]$Report,
    [switch]$Suspects,
    [switch]$Remove,
    [int]$Hours = 24
)

$ErrorActionPreference = 'Continue'
$prefetch = Join-Path $env:SystemRoot 'Prefetch'

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Error "Run this script in an elevated (Administrator) PowerShell."; exit 1 }

if (-not ($Setup -or $Report -or $Suspects -or $Remove)) { $Setup = $false; $Report = $true; $Suspects = $true }

function New-PrefetchAuditRule {
    New-Object System.Security.AccessControl.FileSystemAuditRule(
        'Everyone',
        [System.Security.AccessControl.FileSystemRights]'Delete,DeleteSubdirectoriesAndFiles',
        'ContainerInherit,ObjectInherit', 'None', 'Success')
}

# ======================= SETUP =======================
if ($Setup) {
    Write-Host "Enabling auditing..." -ForegroundColor Cyan
    auditpol /set /subcategory:"File System" /success:enable | Out-Null
    auditpol /set /subcategory:"Process Creation" /success:enable | Out-Null
    reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit" /v ProcessCreationIncludeCmdLine_Enabled /t REG_DWORD /d 1 /f | Out-Null
    wevtutil sl Security /ms:268435456 | Out-Null     # Security log 256 MB

    try {
        $acl = Get-Acl -Path $prefetch -Audit
        $acl.AddAuditRule((New-PrefetchAuditRule))
        Set-Acl -Path $prefetch -AclObject $acl
        Write-Host "Deletion auditing is now ON for $prefetch" -ForegroundColor Green
    } catch {
        Write-Host "Could not set the audit rule on the Prefetch folder: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Fallback: Explorer > $prefetch > Properties > Security > Advanced > Auditing > Add > Everyone > Success > Delete."
    }
    Write-Host "Use the laptop normally, then run with -Report to see what deleted Prefetch files." -ForegroundColor Green
    return
}

# ======================= REMOVE =======================
if ($Remove) {
    try {
        $acl = Get-Acl -Path $prefetch -Audit
        $acl.RemoveAuditRuleAll((New-PrefetchAuditRule)) | Out-Null
        Set-Acl -Path $prefetch -AclObject $acl
        Write-Host "Prefetch deletion auditing removed." -ForegroundColor Green
    } catch { Write-Host "Failed: $($_.Exception.Message)" -ForegroundColor Red }
    return
}

# ======================= REPORT =======================
if ($Report) {
    $since = (Get-Date).AddHours(-$Hours)
    Write-Host ""
    Write-Host "=== Who deleted Prefetch files in the last $Hours hour(s)? ===" -ForegroundColor White

    $del = @()
    $events = Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4663; StartTime = $since } -ErrorAction SilentlyContinue
    foreach ($e in $events) {
        $x = [xml]$e.ToXml(); $d = @{}
        foreach ($i in $x.Event.EventData.Data) { $d[$i.Name] = $i.'#text' }
        if ($d['ObjectName'] -notlike '*\Prefetch\*') { continue }
        try { $mask = [Convert]::ToInt32($d['AccessMask'], 16) } catch { continue }
        if (-not ($mask -band 0x10000)) { continue }                   # DELETE right
        $del += [pscustomobject]@{
            Time = $e.TimeCreated; Process = $d['ProcessName']; User = "$($d['SubjectDomainName'])\$($d['SubjectUserName'])"
            File = [IO.Path]::GetFileName($d['ObjectName'])
        }
    }

    if (-not $del) {
        Write-Host "No Prefetch deletions recorded." -ForegroundColor Yellow
        Write-Host "If you have not run -Setup yet, run it first; only deletions AFTER setup are logged."
    } else {
        # who launched those processes (needs 4688 events)
        $launch = @()
        foreach ($e in (Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4688; StartTime = $since } -ErrorAction SilentlyContinue)) {
            $x = [xml]$e.ToXml(); $d = @{}
            foreach ($i in $x.Event.EventData.Data) { $d[$i.Name] = $i.'#text' }
            $launch += [pscustomobject]@{ Time = $e.TimeCreated; Process = $d['NewProcessName']; Cmd = $d['CommandLine']; Parent = $d['ParentProcessName'] }
        }

        foreach ($g in ($del | Group-Object Process, User | Sort-Object Count -Descending)) {
            $first = ($g.Group | Sort-Object Time | Select-Object -First 1).Time
            $last  = ($g.Group | Sort-Object Time | Select-Object -Last 1).Time
            $proc  = $g.Group[0].Process
            $user  = $g.Group[0].User
            Write-Host ""
            Write-Host ("{0}" -f $proc) -ForegroundColor Red
            Write-Host ("   Deleted {0} Prefetch file(s) as {1}" -f $g.Count, $user)
            Write-Host ("   First: {0}   Last: {1}" -f $first, $last)
            Write-Host ("   Examples: {0}" -f (($g.Group.File | Select-Object -Unique -First 5) -join ', '))

            $starts = $launch | Where-Object { $_.Process -eq $proc -and $_.Time -le $last -and $_.Time -ge $first.AddMinutes(-10) } |
                      Sort-Object Time -Descending | Select-Object -First 3
            foreach ($s in $starts) {
                Write-Host ("   Started {0}  by {1}" -f $s.Time, $s.Parent) -ForegroundColor DarkGray
                if ($s.Cmd) { Write-Host ("      Command: {0}" -f $s.Cmd) -ForegroundColor DarkGray }
            }
            if ($proc -match '\\svchost\.exe$|\\System32\\(services|lsass)\.exe$') {
                Write-Host "   Note: svchost = Windows itself (SysMain trims old .pf files automatically). Not a third-party cleaner." -ForegroundColor Yellow
            }
        }
        $del | Sort-Object Time | Export-Csv "$([Environment]::GetFolderPath('Desktop'))\prefetch-deletions.csv" -NoTypeInformation -Encoding UTF8
        Write-Host ""
        Write-Host "Details saved to Desktop\prefetch-deletions.csv" -ForegroundColor Cyan
    }
}

# ======================= SUSPECTS =======================
if ($Suspects) {
    Write-Host ""
    Write-Host "=== Prefetch state ===" -ForegroundColor White
    $svc = Get-Service SysMain -ErrorAction SilentlyContinue
    $pp  = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" -ErrorAction SilentlyContinue
    $pf  = Get-ChildItem $prefetch -Filter *.pf -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
    Write-Host ("SysMain service : {0} / {1}" -f $svc.Status, $svc.StartType)
    Write-Host ("EnablePrefetcher: {0}  (3 = on, 0 = off)" -f $pp.EnablePrefetcher)
    Write-Host ("Prefetch files  : {0}   newest: {1}" -f @($pf).Count, $(if ($pf) { $pf[0].LastWriteTime } else { 'none' }))

    $words = 'ccleaner|bleachbit|wise (disk|care)|glary|iobit|advanced systemcare|privazer|cleanmypc|cleanup|razer cortex|norton utilities|avg tuneup|tuneup|auslogics|cleaner|optimizer|eraser|wipe|shred|booster'

    Write-Host ""
    Write-Host "=== Installed cleaner / optimizer programs ===" -ForegroundColor White
    $paths = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
    foreach ($sid in (Get-ChildItem Registry::HKEY_USERS -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -notmatch '_Classes$' })) {
        $paths += "Registry::HKEY_USERS\$($sid.PSChildName)\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
    }
    $apps = Get-ItemProperty $paths -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match $words }
    if ($apps) { $apps | ForEach-Object { Write-Host ("  {0} {1}  [{2}]" -f $_.DisplayName, $_.DisplayVersion, $_.Publisher) -ForegroundColor Red } }
    else { Write-Host "  none found" -ForegroundColor Green }

    Write-Host ""
    Write-Host "=== Scheduled tasks that touch Prefetch or look like cleaners ===" -ForegroundColor White
    $hit = $false
    foreach ($t in Get-ScheduledTask -ErrorAction SilentlyContinue) {
        $acts = ($t.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' | '
        $mentionsPrefetch = ($acts -replace '/prefetch:\d+', '') -match 'prefetch'
        $looksLikeCleaner = ($t.TaskPath -notlike '\Microsoft\*') -and ("$($t.TaskName) $acts" -match "$words|Remove-Item|\bdel\b|\brd\b|rmdir|cipher\s+/w")
        if ($mentionsPrefetch -or $looksLikeCleaner) {
            $hit = $true
            Write-Host ("  {0}{1}  [{2}]" -f $t.TaskPath, $t.TaskName, $t.State) -ForegroundColor Red
            Write-Host ("     {0}" -f $acts) -ForegroundColor DarkGray
        }
    }
    if (-not $hit) { Write-Host "  none found" -ForegroundColor Green }

    Write-Host ""
    Write-Host "=== Non-Microsoft services that look like cleaners ===" -ForegroundColor White
    $svcs = Get-CimInstance Win32_Service | Where-Object { "$($_.Name) $($_.DisplayName) $($_.PathName)" -match $words -and $_.PathName -notmatch 'Windows\\System32|Windows Defender' }
    if ($svcs) { $svcs | ForEach-Object { Write-Host ("  {0}  ({1})  {2}" -f $_.DisplayName, $_.State, $_.PathName) -ForegroundColor Red } }
    else { Write-Host "  none found" -ForegroundColor Green }

    Write-Host ""
    Write-Host "=== Startup entries that look like cleaners or mention Prefetch ===" -ForegroundColor White
    $runKeys = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')
    foreach ($sid in (Get-ChildItem Registry::HKEY_USERS -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -notmatch '_Classes$' })) {
        $runKeys += "Registry::HKEY_USERS\$($sid.PSChildName)\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
    }
    $found = $false
    foreach ($k in $runKeys) {
        $p = Get-ItemProperty $k -ErrorAction SilentlyContinue
        if (-not $p) { continue }
        foreach ($prop in $p.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' }) {
            $txt = ("$($prop.Name) $($prop.Value)") -replace '/prefetch:\d+', ''   # Chrome/Edge switch, unrelated
            if ($txt -match "$words|prefetch") {
                $found = $true; Write-Host ("  {0} = {1}" -f $prop.Name, $prop.Value) -ForegroundColor Red
            }
        }
    }
    if (-not $found) { Write-Host "  none found" -ForegroundColor Green }

    Write-Host ""
    Write-Host "Tip: run -Setup, use the laptop for a day, then run -Report for proof of exactly which program deletes the files." -ForegroundColor Cyan
}
