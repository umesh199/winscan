<#
.SYNOPSIS
  Lists software INSTALLED, UNINSTALLED or UPDATED in the last N hours (default 24).

.SOURCES (combined and de-duplicated)
  1. Windows Installer events (Application log)  - exact time, MSI-based apps
  2. Registry "Uninstall" entries with an InstallDate (date only)
  3. Microsoft Store apps installed/updated (package folder creation time)
  4. Snapshot comparison - every run saves the list of installed apps and
     compares with the previous run. This is the only way to catch removals
     of apps that don't use Windows Installer. Run it once to create the
     baseline, then again later (e.g. daily) to see what was added/removed.
  5. Process-creation log (Security 4688) - uninstaller/installer launches.
     Only available if auditing was enabled with check-incognito-24h.ps1 -Setup.

.USAGE (run as Administrator)
  .\app-install-uninstall-24h.ps1
  .\app-install-uninstall-24h.ps1 -Hours 48
  .\app-install-uninstall-24h.ps1 -OutFile D:\app-changes.csv
  .\app-install-uninstall-24h.ps1 -NoSnapshot      # don't update the saved snapshot
#>

param(
    [int]$Hours = 24,
    [string]$OutFile = "$([Environment]::GetFolderPath('Desktop'))\app-changes.csv",
    [switch]$NoSnapshot
)

$now    = Get-Date
$cutoff = $now.AddHours(-$Hours)

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { Write-Host "Tip: run as Administrator for complete results (all users, Security log)." -ForegroundColor Yellow }

$results = New-Object System.Collections.Generic.List[object]
$seen    = @{}

function Add-Change($time, $action, $name, $version, $publisher, $source, $detail, [switch]$NoDedupe) {
    if (-not $name) { return }
    $key = ($action.Split(' ')[0].ToLower()) + '|' + $name.ToLower().Trim()
    if (-not $NoDedupe) {
        if ($seen.ContainsKey($key)) { return }
        $seen[$key] = $true
    }
    $results.Add([pscustomobject]@{
        Time = $time; Action = $action; Name = $name; Version = $version
        Publisher = $publisher; Source = $source; Detail = $detail
    })
}

function Get-Match([string]$text, [string]$pattern) {
    if ($text -match $pattern) { return $Matches[1].Trim() } else { return '' }
}

# ---------- 1) Windows Installer events ----------
$ev = Get-WinEvent -FilterHashtable @{
        LogName = 'Application'; ProviderName = 'MsiInstaller'
        Id = 1033, 1034, 11707, 11724, 11708; StartTime = $cutoff
      } -ErrorAction SilentlyContinue |
      Sort-Object { if ($_.Id -in 1033, 1034) { 0 } else { 1 } }, TimeCreated

foreach ($e in $ev) {
    $m = $e.Message
    if ($e.Id -in 1033, 1034) {
        $name   = Get-Match $m 'Product Name:\s*(.+?)\.\s*Product Version:'
        $ver    = Get-Match $m 'Product Version:\s*(.+?)\.\s*Product Language:'
        $pub    = Get-Match $m 'Manufacturer:\s*(.+?)\.\s*(?:Installation|Removal) success'
        $status = Get-Match $m 'status:\s*(\d+)'
        $act    = if ($e.Id -eq 1033) { 'Installed' } else { 'Uninstalled' }
        if ($status -and $status -ne '0') { $act += " (failed, code $status)" }
        Add-Change $e.TimeCreated $act $name $ver $pub 'Windows Installer log' ''
    } else {
        $name = Get-Match $m 'Product:\s*(.+?)\s+--'
        $act  = switch ($e.Id) { 11707 { 'Installed' } 11724 { 'Uninstalled' } default { 'Installed (failed)' } }
        Add-Change $e.TimeCreated $act $name '' '' 'Windows Installer log' ''
    }
}

# ---------- current installed software (registry) ----------
$uninstPaths = @(
    'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
    'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
)
foreach ($sid in (Get-ChildItem Registry::HKEY_USERS -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -notmatch '_Classes$|^\.DEFAULT$' })) {
    $uninstPaths += "Registry::HKEY_USERS\$($sid.PSChildName)\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
}
$installed = Get-ItemProperty $uninstPaths -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -and $_.SystemComponent -ne 1 -and -not $_.ParentKeyName -and $_.DisplayName -notmatch '^(Update for|Security Update|Hotfix) ' }

# ---------- 2) registry InstallDate ----------
foreach ($a in $installed) {
    if ($a.InstallDate -match '^\d{8}$') {
        $d = [datetime]::ParseExact($a.InstallDate, 'yyyyMMdd', $null)
        if ($d -ge $cutoff.Date) {
            Add-Change $d 'Installed' $a.DisplayName $a.DisplayVersion $a.Publisher 'Registry (date only)' ''
        }
    }
}

# ---------- 3) Microsoft Store apps ----------
$store = @()
try {
    $store = Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue |
        Where-Object { -not $_.IsFramework -and $_.SignatureKind -ne 'System' -and $_.InstallLocation }
    foreach ($p in $store) {
        $ct = (Get-Item -LiteralPath $p.InstallLocation -ErrorAction SilentlyContinue).CreationTime
        if ($ct -and $ct -ge $cutoff) {
            Add-Change $ct 'Installed' $p.Name $p.Version $p.Publisher 'Microsoft Store' 'New install or update of a Store app'
        }
    }
} catch { }

# ---------- 4) snapshot comparison ----------
$snapDir  = Join-Path $env:ProgramData 'AppChangeTracker'
$snapFile = Join-Path $snapDir 'snapshot.json'

$current = @()
$current += $installed | ForEach-Object { [pscustomobject]@{ Name = $_.DisplayName; Version = [string]$_.DisplayVersion; Publisher = [string]$_.Publisher; Source = 'Desktop' } }
$current += $store     | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Version = [string]$_.Version; Publisher = [string]$_.Publisher; Source = 'Store' } }
$current = $current | Group-Object { "$($_.Source)|$($_.Name)".ToLower() } | ForEach-Object { $_.Group[0] }

$snapNote = ''
if (Test-Path $snapFile) {
    try {
        $prev = Get-Content $snapFile -Raw | ConvertFrom-Json
        $prevTime = [datetime]$prev.Time
        $snapNote = "Snapshot compared: $prevTime  ->  $now"
        $pm = @{}; foreach ($x in $prev.Apps) { $pm["$($x.Source)|$($x.Name)".ToLower()] = $x }
        $cm = @{}; foreach ($x in $current)   { $cm["$($x.Source)|$($x.Name)".ToLower()] = $x }

        foreach ($k in $cm.Keys) {
            if (-not $pm.ContainsKey($k)) {
                $x = $cm[$k]
                Add-Change $now 'Installed' $x.Name $x.Version $x.Publisher 'Snapshot comparison' "New since snapshot of $prevTime"
            } elseif ($pm[$k].Version -ne $cm[$k].Version) {
                $x = $cm[$k]
                Add-Change $now 'Updated' $x.Name $x.Version $x.Publisher 'Snapshot comparison' "Version $($pm[$k].Version) -> $($x.Version) since $prevTime"
            }
        }
        foreach ($k in $pm.Keys) {
            if (-not $cm.ContainsKey($k)) {
                $x = $pm[$k]
                Add-Change $now 'Uninstalled' $x.Name $x.Version $x.Publisher 'Snapshot comparison' "Present in snapshot of $prevTime, gone now (exact time unknown)"
            }
        }
    } catch { $snapNote = 'Previous snapshot could not be read; a new baseline was saved.' }
} else {
    $snapNote = 'First run: baseline snapshot saved. Run again later to see installs/removals detected by comparison.'
}
if (-not $NoSnapshot) {
    New-Item -ItemType Directory -Path $snapDir -Force | Out-Null
    [pscustomobject]@{ Time = $now.ToString('s'); Apps = $current } | ConvertTo-Json -Depth 4 | Set-Content $snapFile -Encoding UTF8
}

# ---------- 5) process-creation log hints (optional) ----------
$proc = Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = 4688; StartTime = $cutoff } -ErrorAction SilentlyContinue
foreach ($e in $proc) {
    $x = [xml]$e.ToXml(); $d = @{}
    foreach ($i in $x.Event.EventData.Data) { $d[$i.Name] = $i.'#text' }
    $exe = [IO.Path]::GetFileName($d['NewProcessName']); $cmd = [string]$d['CommandLine']
    if     ($exe -match '^unins\w*\.exe$|^uninstall\w*\.exe$' -or $cmd -match 'msiexec.*(/x|/uninstall)|winget\s+uninstall|choco\s+uninstall') { $act = 'Uninstall launched' }
    elseif ($cmd -match 'msiexec.*(/i|/package)|winget\s+install|choco\s+install')                                                             { $act = 'Install launched' }
    else { continue }
    $label = if ($cmd) { $cmd } else { $d['NewProcessName'] }
    Add-Change $e.TimeCreated $act $label '' '' 'Process log (4688)' "Run by $($d['SubjectUserName'])" -NoDedupe
}

# ---------- report ----------
Write-Host ""
Write-Host "=== Software changes in the last $Hours hour(s) (since $cutoff) ===" -ForegroundColor White
if ($snapNote) { Write-Host $snapNote -ForegroundColor DarkGray }
Write-Host ""

if ($results.Count -eq 0) {
    Write-Host "No installs, uninstalls or updates found." -ForegroundColor Green
    return
}

$sorted = $results | Sort-Object Time -Descending
foreach ($grp in ($sorted | Group-Object { ($_.Action.Split(' ')[0]) })) {
    $color = switch -Wildcard ($grp.Name) { 'Installed' { 'Green' } 'Uninstalled' { 'Red' } 'Updated' { 'Cyan' } default { 'Yellow' } }
    Write-Host "--- $($grp.Name.ToUpper()) ($($grp.Count)) ---" -ForegroundColor $color
    foreach ($r in $grp.Group) {
        $ver = if ($r.Version) { " v$($r.Version)" } else { '' }
        $pub = if ($r.Publisher) { "  [$($r.Publisher)]" } else { '' }
        Write-Host ("  {0:yyyy-MM-dd HH:mm}  {1}{2}{3}" -f $r.Time, $r.Name, $ver, $pub) -ForegroundColor $color
        Write-Host ("                    {0}{1}" -f $r.Source, $(if ($r.Detail) { " - $($r.Detail)" } else { '' })) -ForegroundColor DarkGray
    }
    Write-Host ""
}

$sorted | Export-Csv -Path $OutFile -NoTypeInformation -Encoding UTF8
$cnt = @{}; foreach ($r in $results) { $cnt[$r.Action.Split(' ')[0]] += 1 }
Write-Host ("Installed: {0}   Uninstalled: {1}   Updated: {2}" -f [int]$cnt['Installed'], [int]$cnt['Uninstalled'], [int]$cnt['Updated']) -ForegroundColor Cyan
Write-Host "Report saved to: $OutFile"
