@echo off
setlocal
title Antivirus Genuine Check

REM ---- Self-elevate to Administrator ----
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SCRIPT=%~dp0check-antivirus-genuine.ps1"
if not exist "%SCRIPT%" (
    echo ERROR: check-antivirus-genuine.ps1 must be in the same folder as this .bat file.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
echo.
pause
