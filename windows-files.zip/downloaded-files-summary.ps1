<#
.SYNOPSIS
  Finds files DOWNLOADED from the internet in the last N hours (default 24)
  and summarises what each one is and whether it looks risky.

.DATA SOURCES
  1. NTFS "Zone.Identifier" mark that browsers put on downloaded files
     (gives the source website / referrer).
  2. Chrome / Edge / Brave download history (all user profiles) - this also
     reveals downloads that were later moved or deleted.
     Needs sqlite3.exe (free from sqlite.org). Put it next to this script or
     in PATH. Without it, only source 1 is used.

.USAGE (run as Administrator)
  .\downloaded-files-summary.ps1
  .\downloaded-files-summary.ps1 -Hours 48
  .\downloaded-files-summary.ps1 -Drives C:,D: -OutFile D:\report.csv

.NOTE
  Summaries are rule-based (file type, digital signature, file properties,
  archive contents, suspicious script keywords). They are a quick triage,
  not an antivirus verdict. Use the SHA256 column on virustotal.com to check
  anything marked HIGH.
#>

param(
    [int]$Hours = 24,
    [string[]]$Drives,
    [string]$Sqlite,
    [string]$OutFile = "$([Environment]::GetFolderPath('Desktop'))\downloaded-files-summary.csv"
)

$cutoff = (Get-Date).AddHours(-$Hours)
if (-not $Drives) { $Drives = (Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3").DeviceID }

# ---------- file type knowledge: ext = (label, plain-language note, base risk) ----------
$types = @{
 '.exe'=@('Windows program','Runs code on the PC as soon as it is opened.','High')
 '.msi'=@('Windows installer','Installs software and can change system settings.','High')
 '.msix'=@('App installer','Installs an app package.','Medium')
 '.appx'=@('App installer','Installs an app package.','Medium')
 '.scr'=@('Screensaver program','Actually an executable program in disguise.','High')
 '.com'=@('Legacy program','Executable program.','High')
 '.dll'=@('Program library','Code library loaded by other programs.','High')
 '.bat'=@('Batch script','Runs a list of Windows commands.','High')
 '.cmd'=@('Batch script','Runs a list of Windows commands.','High')
 '.ps1'=@('PowerShell script','Runs PowerShell commands.','High')
 '.vbs'=@('VBScript','Runs a Windows script.','High')
 '.vbe'=@('Encoded VBScript','Runs a (hidden-source) Windows script.','High')
 '.js'=@('JavaScript file','If opened by double-click, Windows runs it as a script.','High')
 '.jse'=@('Encoded JScript','Runs a (hidden-source) Windows script.','High')
 '.wsf'=@('Windows script file','Runs a Windows script.','High')
 '.hta'=@('HTML application','Runs as a full program with system access.','High')
 '.jar'=@('Java program','Runs Java code.','High')
 '.reg'=@('Registry file','Changes Windows registry settings when merged.','High')
 '.lnk'=@('Shortcut','Can launch a program or command.','Medium')
 '.crx'=@('Browser extension','Adds code to the browser.','Medium')
 '.apk'=@('Android app','Android application package.','Medium')
 '.iso'=@('Disk image','Virtual disc; often holds installers.','Medium')
 '.img'=@('Disk image','Virtual disc image.','Medium')
 '.vhd'=@('Virtual disk','Virtual hard disk image.','Medium')
 '.zip'=@('ZIP archive','Compressed bundle of files.','Medium')
 '.rar'=@('RAR archive','Compressed bundle of files.','Medium')
 '.7z'=@('7-Zip archive','Compressed bundle of files.','Medium')
 '.gz'=@('GZip archive','Compressed file.','Medium')
 '.cab'=@('Cabinet archive','Compressed bundle, often used by installers.','Medium')
 '.docm'=@('Word document with macros','Can run macro code when macros are enabled.','Medium')
 '.xlsm'=@('Excel workbook with macros','Can run macro code when macros are enabled.','Medium')
 '.pptm'=@('PowerPoint with macros','Can run macro code when macros are enabled.','Medium')
 '.torrent'=@('Torrent file','Metadata for peer-to-peer downloads.','Medium')
 '.py'=@('Python script','Runs Python code if Python is installed.','Medium')
 '.sh'=@('Shell script','Unix shell script.','Medium')
 '.doc'=@('Word document (old format)','Document; old format can contain macros.','Medium')
 '.xls'=@('Excel workbook (old format)','Spreadsheet; old format can contain macros.','Medium')
 '.docx'=@('Word document','Document.','Low')
 '.xlsx'=@('Excel workbook','Spreadsheet.','Low')
 '.pptx'=@('PowerPoint presentation','Slides.','Low')
 '.pdf'=@('PDF document','Document.','Low')
 '.txt'=@('Text file','Plain text.','Low')
 '.csv'=@('CSV data file','Spreadsheet-style data.','Low')
 '.jpg'=@('Image','Picture.','Low'); '.jpeg'=@('Image','Picture.','Low'); '.png'=@('Image','Picture.','Low')
 '.gif'=@('Image','Picture.','Low'); '.webp'=@('Image','Picture.','Low'); '.bmp'=@('Image','Picture.','Low')
 '.mp3'=@('Audio','Audio file.','Low'); '.wav'=@('Audio','Audio file.','Low')
 '.mp4'=@('Video','Video file.','Low'); '.mkv'=@('Video','Video file.','Low')
 '.avi'=@('Video','Video file.','Low'); '.mov'=@('Video','Video file.','Low')
}
$suspiciousWords = 'Invoke-WebRequest|DownloadString|DownloadFile|Invoke-Expression|\biex\b|FromBase64String|-enc(odedcommand)?\b|WScript\.Shell|schtasks|reg\s+add|net\s+user|certutil|bitsadmin|Start-Process|powershell|mshta|rundll32|CreateObject|ShellExecute|XMLHTTP'

$excludeDirs = @('Windows','Program Files','Program Files (x86)','ProgramData','$Recycle.Bin','System Volume Information',
    'Recovery','PerfLogs','$WinREAgent','Config.Msi','MSOCache','WinSxS','Temp','INetCache','Cache','Code Cache','GPUCache',
    'Cache2','CrashDumps','Packages','WindowsApps','node_modules','.git')

# ---------- helpers ----------
function Get-ZoneInfo([string]$p) {
    $o = [pscustomobject]@{ Has = $false; HostUrl = ''; Referrer = '' }
    try {
        foreach ($l in (Get-Content -LiteralPath $p -Stream Zone.Identifier -ErrorAction Stop)) {
            if ($l -like 'HostUrl=*')     { $o.HostUrl  = $l.Substring(8) }
            if ($l -like 'ReferrerUrl=*') { $o.Referrer = $l.Substring(12) }
        }
        $o.Has = $true
    } catch { }
    return $o
}

function Get-Domain([string]$u) {
    try { return ([uri]$u).Host } catch { return '' }
}

function Copy-LockedFile([string]$src, [string]$dst) {
    $in  = [IO.File]::Open($src, 'Open', 'Read', 'ReadWrite,Delete')
    $out = [IO.File]::Create($dst)
    try { $in.CopyTo($out) } finally { $in.Dispose(); $out.Dispose() }
}

function Get-BrowserDownloads {
    $sq = $Sqlite
    if (-not $sq) {
        $c = Get-Command sqlite3.exe -ErrorAction SilentlyContinue
        if ($c) { $sq = $c.Source }
        elseif (Test-Path "$PSScriptRoot\sqlite3.exe") { $sq = "$PSScriptRoot\sqlite3.exe" }
    }
    if (-not $sq) {
        Write-Host "sqlite3.exe not found - browser history skipped (Zone.Identifier data is still used)." -ForegroundColor Yellow
        return @()
    }
    $webkit = ([DateTimeOffset]::new($cutoff).ToUnixTimeSeconds() + 11644473600) * 1000000
    $browsers = @{ 'Chrome'='Google\Chrome'; 'Edge'='Microsoft\Edge'; 'Brave'='BraveSoftware\Brave-Browser' }
    $found = @()
    foreach ($u in Get-ChildItem "$env:SystemDrive\Users" -Directory -ErrorAction SilentlyContinue) {
        foreach ($b in $browsers.Keys) {
            $ud = Join-Path $u.FullName "AppData\Local\$($browsers[$b])\User Data"
            if (-not (Test-Path $ud)) { continue }
            foreach ($prof in Get-ChildItem $ud -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^(Default|Profile \d+)$' }) {
                $hist = Join-Path $prof.FullName 'History'
                if (-not (Test-Path $hist)) { continue }
                $tmp = Join-Path $env:TEMP "hist_$([guid]::NewGuid()).db"
                try {
                    Copy-LockedFile $hist $tmp
                    $q = "SELECT target_path, tab_url, referrer, start_time, total_bytes, danger_type FROM downloads WHERE start_time >= $webkit ORDER BY start_time DESC"
                    $rows = & $sq -csv -header $tmp $q | ConvertFrom-Csv
                    foreach ($r in $rows) {
                        $found += [pscustomobject]@{
                            Path     = $r.target_path
                            Browser  = "$b ($($u.Name))"
                            PageUrl  = $r.tab_url
                            Referrer = $r.referrer
                            When     = [DateTime]::FromFileTimeUtc([int64]$r.start_time * 10).ToLocalTime()
                            Flagged  = ($r.danger_type -ne '0')
                        }
                    }
                } catch { Write-Host "Could not read $b history for $($u.Name): $($_.Exception.Message)" -ForegroundColor DarkYellow }
                finally { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
            }
        }
    }
    return $found
}

function Get-Analysis([string]$path, [string]$sourceUrl) {
    $ext = [IO.Path]::GetExtension($path).ToLower()
    $t = $types[$ext]
    if (-not $t) { $t = @("Other file ($ext)", 'Unrecognised type; not normally run as a program.', 'Low') }
    $risk = $t[2]; $notes = New-Object System.Collections.Generic.List[string]
    $signer = ''; $sigStatus = ''

    if ($ext -in '.exe','.msi','.dll','.scr') {
        try {
            $vi = (Get-Item -LiteralPath $path).VersionInfo
            $bits = @($vi.FileDescription, $vi.ProductName, $vi.CompanyName) | Where-Object { $_ }
            if ($bits) { $notes.Add("Describes itself as: " + ($bits -join ' / ') + ".") }
        } catch { }
        try {
            $sig = Get-AuthenticodeSignature -LiteralPath $path
            $sigStatus = $sig.Status.ToString()
            if ($sig.SignerCertificate) { $signer = $sig.SignerCertificate.Subject -replace '^.*?CN=([^,]+).*$', '$1' }
            if ($sigStatus -eq 'Valid') { $risk = 'Medium'; $notes.Add("Digitally signed by $signer (signature valid).") }
            else { $risk = 'High'; $notes.Add("NOT validly signed (status: $sigStatus) - publisher cannot be verified.") }
        } catch { }
    }
    elseif ($ext -eq '.zip') {
        try {
            Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
            $z = [IO.Compression.ZipFile]::OpenRead($path)
            $names = @($z.Entries | Where-Object { $_.Name } | ForEach-Object { $_.FullName })
            $z.Dispose()
            $notes.Add("Contains $($names.Count) file(s), e.g. " + (($names | Select-Object -First 5) -join ', ') + ".")
            $run = @($names | Where-Object { $_ -match '\.(exe|msi|bat|cmd|ps1|vbs|js|scr|lnk|hta|jar)$' })
            if ($run.Count) { $risk = 'High'; $notes.Add("Includes runnable files: " + (($run | Select-Object -First 5) -join ', ') + ".") }
        } catch { $notes.Add('Could not read archive (may be password-protected or damaged).') }
    }
    elseif ($ext -in '.bat','.cmd','.ps1','.vbs','.vbe','.js','.jse','.wsf','.hta','.reg','.py','.sh') {
        try {
            $text = Get-Content -LiteralPath $path -TotalCount 400 -ErrorAction Stop | Out-String
            $m = [regex]::Matches($text, $suspiciousWords, 'IgnoreCase') | ForEach-Object { $_.Value.ToLower() } | Sort-Object -Unique
            if ($m) { $notes.Add("Script uses: " + ($m -join ', ') + " (can download or launch other programs).") }
            else    { $notes.Add('No obviously suspicious commands in the first lines.') }
        } catch { }
    }
    elseif ($ext -in '.docm','.xlsm','.pptm') { $notes.Add('Macro-enabled: only enable macros if you trust the sender.') }

    if ($sourceUrl -like 'http://*') {
        $notes.Add('Downloaded over plain http (not encrypted).')
        if ($risk -eq 'Low') { $risk = 'Medium' }
    }

    [pscustomobject]@{
        Type = $t[0]; What = $t[1]; Risk = $risk; Notes = ($notes -join ' ')
        Signer = $signer; Signature = $sigStatus
    }
}

# ---------- 1) browser download history ----------
$browserMap = @{}
foreach ($d in Get-BrowserDownloads) { $browserMap[$d.Path.ToLower()] = $d }

# ---------- 2) scan drives for files carrying the "downloaded" mark ----------
$candidates = @{}
$dummy = Join-Path $env:TEMP 'dl_dummy_dest'
foreach ($drive in $Drives) {
    Write-Host "Scanning $drive ..." -ForegroundColor Cyan
    $log = Join-Path $env:TEMP "dl_scan_$([guid]::NewGuid()).txt"
    $rc = @("$drive\", $dummy, '/L', '/S', '/XJ', '/R:0', '/W:0', '/MAXAGE:2', '/NJH', '/NJS', '/NDL', '/NC', '/NS', '/NP', '/FP',
            "/UNILOG:$log", '/XD') + $excludeDirs + @('/XF', 'pagefile.sys', 'hiberfil.sys', 'swapfile.sys', '*.tmp', 'desktop.ini')
    & robocopy @rc | Out-Null
    if (Test-Path $log) {
        foreach ($line in Get-Content $log -Encoding Unicode) {
            $p = $line.Trim()
            if ($p -notmatch '^[A-Za-z]:\\') { continue }
            try { $it = Get-Item -LiteralPath $p -Force -ErrorAction Stop } catch { continue }
            $changed = if ($it.LastWriteTime -gt $it.CreationTime) { $it.LastWriteTime } else { $it.CreationTime }
            if ($changed -lt $cutoff) { continue }
            if (Get-Item -LiteralPath $p -Stream Zone.Identifier -ErrorAction SilentlyContinue) { $candidates[$p.ToLower()] = $p }
        }
        Remove-Item $log -Force -ErrorAction SilentlyContinue
    }
}
foreach ($k in $browserMap.Keys) { if (-not $candidates.ContainsKey($k)) { $candidates[$k] = $browserMap[$k].Path } }

# ---------- 3) analyse ----------
$results = foreach ($key in $candidates.Keys) {
    $path = $candidates[$key]
    $bh = $browserMap[$key]
    $exists = Test-Path -LiteralPath $path
    $zone = if ($exists) { Get-ZoneInfo $path } else { [pscustomobject]@{ HostUrl=''; Referrer='' } }

    $sourceUrl = if ($zone.HostUrl -and $zone.HostUrl -ne 'about:internet') { $zone.HostUrl } elseif ($bh) { $bh.PageUrl } else { '' }
    $referrer  = if ($zone.Referrer) { $zone.Referrer } elseif ($bh) { $bh.Referrer } else { '' }
    $a = Get-Analysis $path $sourceUrl

    $size = ''; $sha = ''; $when = $null
    if ($exists) {
        $it = Get-Item -LiteralPath $path -Force
        $size = [math]::Round($it.Length / 1MB, 2)
        $when = if ($it.LastWriteTime -gt $it.CreationTime) { $it.LastWriteTime } else { $it.CreationTime }
        if ($it.Length -lt 500MB) { try { $sha = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash } catch { } }
    } else {
        $when = if ($bh) { $bh.When } else { $null }
    }
    $risk = $a.Risk
    if ($bh -and $bh.Flagged) { $risk = 'High'; $a.Notes = ($a.Notes + ' Browser Safe Browsing flagged this download as dangerous.').Trim() }
    if (-not $exists) { $a.Notes = ('File no longer on disk (deleted or moved after download). ' + $a.Notes).Trim() }

    [pscustomobject]@{
        Time = $when; Risk = $risk; Name = [IO.Path]::GetFileName($path); Type = $a.Type
        SizeMB = $size; SourceSite = (Get-Domain $sourceUrl); SourceUrl = $sourceUrl; Referrer = $referrer
        Browser = if ($bh) { $bh.Browser } else { '' }
        Signer = $a.Signer; Signature = $a.Signature
        Summary = ("$($a.What) $($a.Notes)").Trim()
        OnDisk = $exists; SHA256 = $sha; Path = $path
    }
}

# ---------- 4) report ----------
if (-not $results) {
    Write-Host "No downloaded files found in the last $Hours hour(s)." -ForegroundColor Green
    return
}
$order = @{ 'High' = 0; 'Medium' = 1; 'Low' = 2 }
$sorted = $results | Sort-Object @{ e = { $order[$_.Risk] } }, @{ e = 'Time'; Descending = $true }

Write-Host ""
Write-Host "=== Files downloaded in the last $Hours hour(s) ===" -ForegroundColor White
foreach ($r in $sorted) {
    $color = switch ($r.Risk) { 'High' { 'Red' } 'Medium' { 'Yellow' } default { 'Green' } }
    Write-Host ("[{0}] {1}  ({2}{3})" -f $r.Risk.ToUpper(), $r.Name, $(if ($r.SizeMB -ne '') { "$($r.SizeMB) MB, " } else { '' }), $r.Time) -ForegroundColor $color
    Write-Host ("   From : {0}{1}" -f $(if ($r.SourceSite) { $r.SourceSite } else { 'unknown source' }), $(if ($r.Browser) { "  via $($r.Browser)" } else { '' }))
    Write-Host ("   What : {0}" -f $r.Summary)
    Write-Host ("   Where: {0}" -f $r.Path)
    Write-Host ""
}
$sorted | Export-Csv -Path $OutFile -NoTypeInformation -Encoding UTF8
$hi = @($results | Where-Object Risk -eq 'High').Count
Write-Host "$($results.Count) download(s): $hi high-risk, $(@($results | Where-Object Risk -eq 'Medium').Count) medium, $(@($results | Where-Object Risk -eq 'Low').Count) low." -ForegroundColor Cyan
Write-Host "Full report saved to: $OutFile"
