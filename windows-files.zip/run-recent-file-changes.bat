@echo off
setlocal
title Recent File Changes (last 24 hours)

REM ---- Self-elevate so all user folders can be read ----
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SCRIPT=%~dp0recent-file-changes.ps1"
if not exist "%SCRIPT%" (
    echo ERROR: recent-file-changes.ps1 must be in the same folder as this .bat file.
    pause
    exit /b 1
)

:menu
echo.
echo ==========================================
echo   Files changed in the last 24 hours
echo ==========================================
echo   1. All user files (system files excluded)
echo   2. Only downloaded files
echo   3. Exit
echo.
set /p choice=Choose an option (1-3): 

if "%choice%"=="1" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%"
if "%choice%"=="2" powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -DownloadedOnly
if "%choice%"=="3" exit /b

echo.
pause
goto menu
